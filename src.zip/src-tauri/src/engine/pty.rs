use parking_lot::Mutex;
use portable_pty::MasterPty;
use std::io::{Read, Write};
use std::panic::{catch_unwind, AssertUnwindSafe};
use std::sync::atomic::{AtomicI64, Ordering};
use std::sync::Arc;
use std::time::{SystemTime, UNIX_EPOCH};
use uuid::Uuid;

use crate::engine::cwd;
use crate::engine::title;
use crate::state::AppState;
use crate::types::GlobalEvent;
use crate::utils::pty_log;

const PTY_READ_UTF8_PENDING_MAX: usize = 64 * 1024;

/// 统一 cwd 表示（Windows 下反斜杠 → 正斜杠），与 `process::normalize_cwd` 对齐，
/// 避免 `paneCwdStore` 上出现 `C:\code\ridge` 与 `C:/code/ridge` 两个键并存的别名。
fn normalize_cwd_str(raw: &str) -> String {
    #[cfg(windows)]
    {
        raw.replace('\\', "/")
    }
    #[cfg(not(windows))]
    {
        raw.to_string()
    }
}

/// Extend `pending` with `chunk`, then drain leading complete UTF-8 into `String`.
/// Incomplete trailing bytes remain in `pending` for the next read.
fn take_decoded_utf8(pending: &mut Vec<u8>, chunk: &[u8]) -> String {
    if !chunk.is_empty() {
        pending.extend_from_slice(chunk);
    }
    if pending.len() > PTY_READ_UTF8_PENDING_MAX {
        let bytes = std::mem::replace(pending, Vec::new());
        return String::from_utf8_lossy(&bytes).into_owned();
    }
    let mut out = String::new();
    loop {
        if pending.is_empty() {
            break;
        }
        match std::str::from_utf8(pending) {
            Ok(s) => {
                out.push_str(s);
                pending.clear();
                break;
            }
            Err(e) => {
                let valid = e.valid_up_to();
                if valid > 0 {
                    out.push_str(unsafe { std::str::from_utf8_unchecked(&pending[..valid]) });
                    pending.drain(..valid);
                    continue;
                }
                if let Some(elen) = e.error_len() {
                    out.push_str(&String::from_utf8_lossy(&pending[..elen]));
                    pending.drain(..elen);
                    continue;
                }
                break;
            }
        }
    }
    out
}

fn flush_pending_eof(pending: &mut Vec<u8>) -> String {
    if pending.is_empty() {
        return String::new();
    }
    let bytes = std::mem::replace(pending, Vec::new());
    String::from_utf8_lossy(&bytes).into_owned()
}

pub struct PtyHandle {
    pub master: Arc<Mutex<Box<dyn MasterPty + Send>>>,
    pub writer: Arc<Mutex<Box<dyn Write + Send>>>,
    pub _child: Box<dyn portable_pty::Child + Send + Sync>,
    /// Resize-silence deadline in epoch milliseconds. When `> 0` and `now < deadline`,
    /// the PTY reader thread suppresses scrollback writes AND frontend emits to swallow
    /// ConPTY's viewport-replay byte storm. Cleared (set to 0) the moment a prompt OSC
    /// (`OSC 133;A/B/P` FinalTerm or `OSC 633;A/B/P` VS Code shell-integration) is seen
    /// in the byte stream, OR when the hard timeout elapses.
    pub resize_silence_deadline: Arc<AtomicI64>,
}

/// 默认 resize 静默窗口（毫秒）。ConPTY 在 `ResizePseudoConsole` 后会把整个
/// viewport 通过 stdout 重发；这段重发到 PTY 读端的延迟一般在 50-300ms。
/// 800ms 给 shell 的 SIGWINCH handler + 重画 prompt 留够余量；若 shell 启用了
/// shell-integration（OSC 133/633），通常远在 800ms 之前就被截断退出静默。
pub const RESIZE_SILENCE_WINDOW_MS: i64 = 800;

/// 当前 epoch 毫秒；时钟异常时返回 0（导致 `silent` 判定为 false，安全降级）。
fn now_epoch_ms() -> i64 {
    SystemTime::now()
        .duration_since(UNIX_EPOCH)
        .map(|d| d.as_millis() as i64)
        .unwrap_or(0)
}

/// 在 `data` 中查找最早出现的 shell-integration prompt OSC 起始字节偏移。
///
/// 检测下列序列起始（任一前 7 字节，不要求匹配 ST/BEL 终止符 —— xterm.js 会
/// 在收到流后自行解析完整序列）：
/// - `\x1b]133;A` / `\x1b]133;B` / `\x1b]133;P` — FinalTerm 语义 prompt 协议
/// - `\x1b]633;A` / `\x1b]633;B` / `\x1b]633;P` — VS Code shell-integration 扩展
///
/// 返回首个命中的字节偏移（基于原 `data: &str` 的字节位置，可安全用于
/// `data[off..]` 切片）。若未命中，返回 `None`。
fn find_prompt_osc(data: &str) -> Option<usize> {
    const MARKERS: [&str; 6] = [
        "\x1b]133;A",
        "\x1b]133;B",
        "\x1b]133;P",
        "\x1b]633;A",
        "\x1b]633;B",
        "\x1b]633;P",
    ];
    let mut earliest: Option<usize> = None;
    for m in MARKERS.iter() {
        if let Some(idx) = data.find(m) {
            earliest = Some(earliest.map_or(idx, |e| e.min(idx)));
        }
    }
    earliest
}

/// 从工作区表里摘掉该 pane 的 PTY（读线程结束或异常时用）。不影响其它 pane 的表项。
fn detach_terminal(state: &AppState, workspace_id: Uuid, pane_id: Uuid) {
    state.clear_pty_scrollback(workspace_id, pane_id);
    let mut map = state.workspaces.write();
    if let Some(ws) = map.get_mut(&workspace_id) {
        ws.terminals.remove(&pane_id);
    }
}

/// 在独立线程里阻塞读 PTY，经 `Handle::block_on` 写回 channel，避免占满 Tokio worker。
///
/// 隔离性说明（root 崩溃不影响兄弟窗格）：
/// - 每个窗格对应 **独立子进程 + 独立 PTY**，与 UI 上叫 `root` 还是子 UUID 无关；OS 上互为兄弟进程。
/// - 本线程只操作本 pane 的 `reader` 与本 workspace 的 **单条** `terminals[pane_id]`；`catch_unwind` 避免本线程 panic 直接终止整个进程。
/// - 读结束后 `detach_terminal` 只删除当前 id，**不会**遍历或修改其它 pane。
/// - 仍属同一 Tauri 进程：若 native 库段错误或 `panic = abort`，理论上仍可能全进程退出——需进程级隔离才有硬保证。
pub fn spawn_pty_reader(
    state: AppState,
    workspace_id: Uuid,
    pane_id: Uuid,
    mut reader: Box<dyn Read + Send>,
) {
    let handle = tokio::runtime::Handle::try_current();
    // Clone the silence-deadline Arc once at thread start (single read-lock acquire),
    // so the per-iteration silence check is a pure atomic load with no map locking.
    // If the handle is gone (race with rapid open+close), fall back to a fresh atomic
    // — silence will simply never activate, which is safe.
    let silence_deadline: Arc<AtomicI64> = {
        let map = state.workspaces.read();
        map.get(&workspace_id)
            .and_then(|ws| ws.terminals.get(&pane_id))
            .map(|h| h.resize_silence_deadline.clone())
            .unwrap_or_else(|| Arc::new(AtomicI64::new(0)))
    };
    let _ = std::thread::Builder::new()
        .name(format!("pty-reader-{pane_id}"))
        .spawn(move || {
            let Ok(rt) = handle else {
                pty_log::reader_no_runtime(workspace_id, pane_id);
                return;
            };
            let mut buf = [0u8; 8192];
            let mut utf8_pending: Vec<u8> = Vec::new();
            let read_result = catch_unwind(AssertUnwindSafe(|| {
                loop {
                    match reader.read(&mut buf) {
                        Ok(0) => {
                            let tail = flush_pending_eof(&mut utf8_pending);
                            if !tail.is_empty() {
                                let tail_for_cwd = tail.clone();
                                state.append_pty_scrollback(workspace_id, pane_id, &tail);
                                let _ = rt.block_on(async {
                                    state
                                        .event_tx
                                        .send(GlobalEvent::PtyOutput {
                                            workspace_id,
                                            pane_id,
                                            data: tail,
                                        })
                                        .await
                                });
                                if let Some(cwd) = cwd::parse_cwd_from_output(&tail_for_cwd) {
                                    {
                                        let mut map = state.workspaces.write();
                                        if let Some(ws) = map.get_mut(&workspace_id) {
                                            if let Some(pane) = ws.pane_tree.panes.get_mut(&pane_id) {
                                                pane.cwd = Some(std::path::PathBuf::from(normalize_cwd_str(&cwd.to_string_lossy())));
                                                tracing::debug!(target: "ridge::cwd", workspace = %workspace_id, pane = %pane_id, cwd = %cwd.display(), "OSC 7 cwd applied");
                                            }
                                        }
                                    }
                                    crate::commands::ridge_file::schedule_auto_save(&state, workspace_id);
                                    let event_tx = state.event_tx.clone();
                                    let workspace_id = workspace_id.clone();
                                    let pane_id = pane_id.clone();
                                    let cwd_clone = cwd.clone();
                                    let _ = rt.block_on(async move {
                                        let _ = event_tx
                                            .send(GlobalEvent::PaneCwdChanged {
                                                workspace_id,
                                                pane_id,
                                                cwd: normalize_cwd_str(&cwd_clone.to_string_lossy()),
                                            })
                                            .await;
                                    });
                                }
                            }
                            pty_log::reader_eof(workspace_id, pane_id);
                            break;
                        }
                        Ok(n) => {
                            let raw = take_decoded_utf8(&mut utf8_pending, &buf[..n]);
                            if raw.is_empty() {
                                continue;
                            }
                            // Resize silence: while ConPTY is replaying its viewport
                            // post-`ResizePseudoConsole`, drop bytes from BOTH scrollback
                            // and frontend emit until the next prompt OSC (FinalTerm
                            // OSC 133;A / VS Code OSC 633;A) tells us the shell is back
                            // at a clean prompt. Hard timeout (800ms) auto-releases for
                            // shells without shell-integration so we don't permanently
                            // mute the pane.
                            let deadline = silence_deadline.load(Ordering::Acquire);
                            let silenced = deadline > 0 && now_epoch_ms() < deadline;
                            let data = if silenced {
                                match find_prompt_osc(&raw) {
                                    Some(off) => {
                                        // Prompt OSC found — release silence and keep
                                        // only the post-OSC tail. Pre-OSC bytes are
                                        // ConPTY reflow noise; dropping them is the
                                        // whole point of this gate.
                                        silence_deadline.store(0, Ordering::Release);
                                        raw[off..].to_string()
                                    }
                                    None => {
                                        // Still inside reflow storm; drop bytes.
                                        // (Original outputs were already captured into
                                        // scrollback BEFORE the resize, so this drop
                                        // doesn't lose user-visible history.)
                                        continue;
                                    }
                                }
                            } else {
                                // Either never silenced, or silenced-but-timed-out.
                                // Reset deadline opportunistically so the next iteration
                                // doesn't redo the time math.
                                if deadline > 0 {
                                    silence_deadline.store(0, Ordering::Release);
                                }
                                raw
                            };
                            if data.is_empty() {
                                continue;
                            }
                            let data_for_cwd = data.clone();
                            let bytes_for_title = data.as_bytes().to_vec();
                            state.append_pty_scrollback(workspace_id, pane_id, &data);
                            let _ = rt.block_on(async {
                                state
                                    .event_tx
                                    .send(GlobalEvent::PtyOutput {
                                        workspace_id,
                                        pane_id,
                                        data,
                                    })
                                    .await
                            });
                            // T1：扫描 OSC 0/1/2 标题序列。shell 提示符、Claude Code、
                            // ssh 等都用这条机制设置窗口标题，emit 后前端按 teammate >
                            // OSC > 进程名 优先级合并展示。
                            if let Some(title_text) =
                                title::parse_title_from_output(&bytes_for_title)
                            {
                                let event_tx = state.event_tx.clone();
                                let _ = rt.block_on(async move {
                                    let _ = event_tx
                                        .send(GlobalEvent::PaneTitleChanged {
                                            workspace_id,
                                            pane_id,
                                            title: title_text,
                                        })
                                        .await;
                                });
                            }
                            if let Some(cwd) = cwd::parse_cwd_from_output(&data_for_cwd) {
                                // Normalize path separators on Windows so every code path
                                // (main-loop OSC 7, EOF flush, process-poll) stores and
                                // emits the SAME string for the same directory.
                                // Without this, Git Bash emits "C:/code" while PowerShell
                                // shell-integration emits "C:\code", and paneCwdStore ends
                                // up with two different keys for the same directory —
                                // preventing the Explorer file-tree column merge.
                                let normalized = normalize_cwd_str(&cwd.to_string_lossy());
                                {
                                    let mut map = state.workspaces.write();
                                    if let Some(ws) = map.get_mut(&workspace_id) {
                                        if let Some(pane) = ws.pane_tree.panes.get_mut(&pane_id) {
                                            pane.cwd = Some(std::path::PathBuf::from(&normalized));
                                        }
                                    }
                                }
                                let event_tx = state.event_tx.clone();
                                let workspace_id = workspace_id.clone();
                                let pane_id = pane_id.clone();
                                let _ = rt.block_on(async move {
                                    let _ = event_tx
                                        .send(GlobalEvent::PaneCwdChanged {
                                            workspace_id,
                                            pane_id,
                                            cwd: normalized,
                                        })
                                        .await;
                                });
                            }
                        }
                        Err(e) => {
                            let tail = flush_pending_eof(&mut utf8_pending);
                            if !tail.is_empty() {
                                let tail_for_cwd = tail.clone();
                                state.append_pty_scrollback(workspace_id, pane_id, &tail);
                                let _ = rt.block_on(async {
                                    state
                                        .event_tx
                                        .send(GlobalEvent::PtyOutput {
                                            workspace_id,
                                            pane_id,
                                            data: tail,
                                        })
                                        .await
                                });
                                if let Some(cwd) = cwd::parse_cwd_from_output(&tail_for_cwd) {
                                    {
                                        let mut map = state.workspaces.write();
                                        if let Some(ws) = map.get_mut(&workspace_id) {
                                            if let Some(pane) = ws.pane_tree.panes.get_mut(&pane_id) {
                                                pane.cwd = Some(std::path::PathBuf::from(normalize_cwd_str(&cwd.to_string_lossy())));
                                                tracing::debug!(target: "ridge::cwd", workspace = %workspace_id, pane = %pane_id, cwd = %cwd.display(), "OSC 7 cwd applied");
                                            }
                                        }
                                    }
                                    crate::commands::ridge_file::schedule_auto_save(&state, workspace_id);
                                    let event_tx = state.event_tx.clone();
                                    let workspace_id = workspace_id.clone();
                                    let pane_id = pane_id.clone();
                                    let cwd_clone = cwd.clone();
                                    let _ = rt.block_on(async move {
                                        let _ = event_tx
                                            .send(GlobalEvent::PaneCwdChanged {
                                                workspace_id,
                                                pane_id,
                                                cwd: normalize_cwd_str(&cwd_clone.to_string_lossy()),
                                            })
                                            .await;
                                    });
                                }
                            }
                            pty_log::reader_io_err(workspace_id, pane_id, &e);
                            break;
                        }
                    }
                }
            }));

            if read_result.is_err() {
                eprintln!(
                    "[ridge] PTY reader panicked (isolated to this thread) workspace={workspace_id} pane={pane_id}"
                );
            }

            let _ = rt.block_on(async {
                state
                    .event_tx
                    .send(GlobalEvent::PaneClosed {
                        workspace_id,
                        pane_id,
                    })
                    .await
            });

            detach_terminal(&state, workspace_id, pane_id);
        });
}