﻿<!-- src/routes/+page.svelte -->
<script lang="ts">

// Monaco Editor Worker 配置 - 必须在使用 monaco 之前配置
import editorWorker from 'monaco-editor/esm/vs/editor/editor.worker?worker';
import jsonWorker from 'monaco-editor/esm/vs/language/json/json.worker?worker';
import cssWorker from 'monaco-editor/esm/vs/language/css/css.worker?worker';
import htmlWorker from 'monaco-editor/esm/vs/language/html/html.worker?worker';
import tsWorker from 'monaco-editor/esm/vs/language/typescript/ts.worker?worker';

self.MonacoEnvironment = {
  getWorker(_: unknown, label: string) {
    if (label === 'json') {
      return new jsonWorker();
    }
    if (label === 'css' || label === 'scss' || label === 'less') {
      return new cssWorker();
    }
    if (label === 'html' || label === 'handlebars' || label === 'razor') {
      return new htmlWorker();
    }
    if (label === 'typescript' || label === 'javascript') {
      return new tsWorker();
    }
    return new editorWorker();
  }
};
  import SplitContainer from '$lib/components/SplitContainer.svelte';
  import SourceControl from '$lib/components/SourceControl.svelte';
  import WorkspaceTabs from '$lib/components/WorkspaceTabs.svelte';
  import Explorer from '$lib/components/Explorer.svelte';
  import FileEditor from '$lib/components/FileEditor.svelte';
  import ContextMenu from '$lib/components/ContextMenu.svelte';
  import ClaudeAgentLauncher from '$lib/components/ClaudeAgentLauncher.svelte';
  import ScrollbackHistoryModal from '$lib/components/ScrollbackHistoryModal.svelte';
  // DiffEditorModal removed — diff view integrated into FileEditor tabs
  import WindDialog from '$lib/components/RidgeDialog.svelte';
  import WindToast from '$lib/components/WindToast.svelte';
  import ClaudeCodePanel from '$lib/components/ClaudeCodePanel.svelte';
  import { settingsStore, initSettingsBoot } from '$lib/stores/settings';
  import SettingsPanel from '$lib/components/SettingsPanel.svelte';
  import { Bot } from 'lucide-svelte';
  import SearchSidebar from '$lib/components/SearchSidebar.svelte';
  import SidebarPluginRegion from '$lib/components/SidebarPluginRegion.svelte';
  import { portal } from '$lib/actions/portal';
  // Side-effect import: each built-in plugin auto-registers via its module
  // script. Must land once, at app chrome level.
  import '$lib/plugins';
  import {
    Terminal,
    FolderOpen,
    GitBranch,
    Layout,
    ChevronLeft,
    ChevronRight,
    ChevronDown,
    Split,
    X,
    Maximize2,
    Minimize2,
    Copy,
    Trash2,
    Plus,
    Minus,
    MoreHorizontal,
    Columns,
    Rows,
    Download,
    ArrowDown,
    ArrowUp,
    Settings,
    FileCode,
    FolderInput,
    Search,
    PanelRightOpen,
    RefreshCw,
  } from 'lucide-svelte';
  import {
    paneTreeStore,
    activePaneId,
    splitActivePane,
    syncPaneLayoutFromBackend,
    refreshWorkspaces,
    workspacesList,
    activeWorkspaceId,
    createWorkspace,
    switchWorkspace,
    getAllPaneIds,
    closeWorkspace,
    reorderWorkspaces,
    renameWorkspace,
    saveCurrentWorkspace,
    loadSavedWorkspaces,
    getStartupContext,
    openWorkspaceFromFile,
    refreshWorkspaceSaveInfo,
    listRecentWorkspaces,
    clearRecentWorkspaces,
    closePane,
    paneCwdStore,
  } from '$lib/stores/paneTree';
  import { fileEditorStore } from '$lib/stores/fileEditor';
  import { initFileWatcherSync } from '$lib/stores/fileWatcherSync';
  import { getScmSelectedRepo } from '$lib/stores/scmCache';
  import {
    alertDialog,
    confirmDialog,
    promptDialog,
  } from '$lib/components/RidgeDialog.svelte';

  // ─── 打开 .ridge 入口 + 最近打开下拉（使用 tauri-plugin-dialog 的 OS 原生文件选择器）───
  let recentOpen = $state(false);
  let recentList = $state<string[]>([]);
  let recentBtn: HTMLButtonElement | undefined = $state();
  let recentPopupStyle = $state('');
  async function loadRecentAndToggle() {
    recentList = await listRecentWorkspaces();
    if (!recentOpen && recentBtn) {
      const r = recentBtn.getBoundingClientRect();
      recentPopupStyle = `top:${r.bottom + 4}px;left:${r.left}px`;
    }
    recentOpen = !recentOpen;
  }
  function basenameOf(p: string): string {
    return p.split(/[/\\]/).filter(Boolean).pop() || p;
  }
  function dirnameOf(p: string): string {
    const parts = p.split(/[/\\]/).filter(Boolean);
    if (parts.length <= 1) return '';
    return parts.slice(0, -1).join('/');
  }
  async function openRecent(path: string) {
    recentOpen = false;
    try {
      await openWorkspaceFromFile(path);
    } catch (err) {
      await alertDialog({ title: '打开失败', message: String(err), danger: true });
    }
  }
  async function handleClearRecent() {
    await clearRecentWorkspaces();
    recentList = [];
    recentOpen = false;
  }
  async function pickAndOpenWorkspace() {
    recentOpen = false;
    try {
      const { open: openDialog } = await import('@tauri-apps/plugin-dialog');
      const picked = await openDialog({
        multiple: false,
        filters: [{ name: 'Ridge Workspace', extensions: ['ridge'] }],
        title: '打开 .ridge 工作区',
      });
      if (typeof picked === 'string' && picked) {
        await openWorkspaceFromFile(picked);
      }
    } catch (err) {
      await alertDialog({ title: '打开失败', message: String(err), danger: true });
    }
  }
  import {
    hideContextMenu,
    showContextMenu,
    isResizeInProgress,
    type ContextMenuTarget,
    type ContextMenuItem,
  } from '$lib/stores/contextMenu';
  import type { PaneNode } from '$lib/stores/paneTree';
  import { reportDevIssue } from '$lib/devIssue';
  import { dev } from '$app/environment';
  import { get } from 'svelte/store';
  import { onMount } from 'svelte';
  import { invoke, isTauri } from '@tauri-apps/api/core';
  import { listen } from '@tauri-apps/api/event';
  import { getCurrentWindow } from '@tauri-apps/api/window';

  let rootNode = $derived($paneTreeStore);
  let hasPaneLayout = $derived(getAllPaneIds(rootNode).length > 0);

  type SidebarTab = 'git' | 'files' | 'search' | 'claude';
  let sidebarTab = $state<SidebarTab>('files');

  // If the Claude extension toggle flips to false while we're on the
  // Claude tab, fall back to Files. Without this guard the user would
  // see an empty sidebar (rail button gone, but tab still active).
  $effect(() => {
    if (!$settingsStore.claudeExtensionEnabled && sidebarTab === 'claude') {
      sidebarTab = 'files';
    }
  });

  // localStorage 键名
  const SIDEBAR_WIDTH_KEY = 'ridge-sidebar-width';
  const SIDEBAR_COLLAPSED_KEY = 'ridge-sidebar-collapsed';

  // 侧边栏宽度状态（用于可拖拽调整大小）
  let sidebarWidth = $state(288); // 默认 w-72 = 288px
  // 侧边栏是否折叠
  let sidebarCollapsed = $state(false);
  let isResizingSidebar = $state(false);

  // Sidebar resize cap. Tracked as $state (not just $derived) so a
  // window-level `resize` listener can push updates — `window.innerWidth`
  // isn't reactive on its own. Cap was 40% (sidebarMaxPx) until
  // round-39 user feedback bumped it to 80% to give SCM/diff users
  // genuinely wide working space without bumping a hard wall.
  let viewportInnerWidth = $state(
    typeof window !== 'undefined' ? window.innerWidth : 1000
  );
  let sidebarMaxPx = $derived(viewportInnerWidth * 0.8);

  // 设置面板开关。Settings 按钮打开后，所有可配置项（主题、字体、搜索、扩展）
  // 都集中在 SettingsPanel 内 —— 鼠标无需在多个角落寻找各自的入口。
  let settingsPanelOpen = $state(false);

  // 从 localStorage 加载侧边栏设置
  function loadSidebarSettings() {
    if (typeof localStorage === 'undefined') return;
    const savedWidth = localStorage.getItem(SIDEBAR_WIDTH_KEY);
    const savedCollapsed = localStorage.getItem(SIDEBAR_COLLAPSED_KEY);
    if (savedWidth) {
      const parsed = parseInt(savedWidth, 10);
      if (!isNaN(parsed) && parsed > 0) {
        sidebarWidth = Math.min(parsed, sidebarMaxPx);
      }
    }
    if (savedCollapsed === 'true') {
      sidebarCollapsed = true;
    }
  }

  // 保存侧边栏设置到 localStorage
  function saveSidebarSettings() {
    if (typeof localStorage === 'undefined') return;
    localStorage.setItem(SIDEBAR_WIDTH_KEY, String(sidebarWidth));
    localStorage.setItem(SIDEBAR_COLLAPSED_KEY, String(sidebarCollapsed));
  }

  // 切换侧边栏折叠状态
function toggleSidebar() {
  if (sidebarCollapsed) {
    // 展开到默认宽度
    sidebarCollapsed = false;
    sidebarWidth = 288; // 默认 w-72
  } else {
    sidebarCollapsed = true;
  }
  saveSidebarSettings();
}

// 展开侧边栏（不切换折叠状态，用于 tab 切换时）
function expandSidebar() {
  if (sidebarCollapsed) {
    sidebarCollapsed = false;
    sidebarWidth = 288;
    saveSidebarSettings();
  }
}

  // 侧边栏折叠/展开时的宽度
  const COLLAPSED_WIDTH = 0;

  function onSidebarResizerMouseDown(e: MouseEvent) {
    e.preventDefault();
    e.stopPropagation();
    isResizingSidebar = true;
    const startX = e.clientX;
    const startWidth = sidebarWidth;

    function onMouseMove(ev: MouseEvent) {
      const delta = ev.clientX - startX;
      const maxWidth = sidebarMaxPx;
      const newWidth = startWidth + delta;
      // 允许拖动到0关闭侧边栏
      sidebarWidth = Math.max(0, Math.min(maxWidth, newWidth));
      // 如果宽度小于20px，自动折叠
      if (sidebarWidth < 20) {
        sidebarCollapsed = true;
        sidebarWidth = 0;
      }
    }

    function onMouseUp() {
      isResizingSidebar = false;
      window.removeEventListener('mousemove', onMouseMove);
      window.removeEventListener('mouseup', onMouseUp);
      // 保存设置
      saveSidebarSettings();
    }

    window.addEventListener('mousemove', onMouseMove);
    window.addEventListener('mouseup', onMouseUp);
  }

  // 键盘快捷键处理
  function handleGlobalKeydown(e: KeyboardEvent) {
    // 全局禁止页面刷新（F5 / Ctrl+R / Ctrl+Shift+R / Cmd+R）
    if (e.key === 'F5' || ((e.ctrlKey || e.metaKey) && (e.key === 'r' || e.key === 'R'))) {
      e.preventDefault();
      return;
    }
    // Ctrl+B: 切换侧边栏
    if (e.ctrlKey && (e.key === 'b' || e.key === 'B')) {
      e.preventDefault();
      toggleSidebar();
      return;
    }
    // Ctrl+Shift+F: 打开搜索侧栏（VS Code 对齐）。展开侧栏（若折叠）+ 切 tab。
    if (e.ctrlKey && e.shiftKey && (e.key === 'f' || e.key === 'F')) {
      e.preventDefault();
      sidebarTab = 'search';
      if (sidebarCollapsed) {
        sidebarCollapsed = false;
        saveSidebarSettings();
      }
      return;
    }
    // Ctrl+A: 全选当前文本输入框的所有文本 (只在输入框/textarea上生效)
    if (e.ctrlKey && (e.key === 'a' || e.key === 'A')) {
      const target = e.target as HTMLElement | null;
      if (
        target &&
        (target.tagName === 'INPUT' ||
          target.tagName === 'TEXTAREA' ||
          target.isContentEditable)
      ) {
        // 让浏览器默认行为处理全选
        return;
      }
      // 如果不是文本输入元素，阻止默认行为（避免误触）
      e.preventDefault();
    }
  }

  // 切换侧边栏tab时加载历史工作区
  $effect(() => {
    void sidebarTab; // 订阅 sidebarTab 变化
    void loadSavedWorkspaces();
  });

  // 窗口控制
  let isMaximized = $state(false);

  async function handleMinimize() {
    if (!isTauri()) return;
    const win = getCurrentWindow();
    await win.minimize();
  }

  async function handleMaximize() {
    if (!isTauri()) return;
    const win = getCurrentWindow();
    await win.toggleMaximize();
    isMaximized = await win.isMaximized();
  }

  async function handleClose() {
    if (!isTauri()) return;
    const win = getCurrentWindow();
    await win.close();
  }

  function openDevIssueHelp() {
    reportDevIssue({
      title: 'Ridge Dev',
      message:
        '排障入口：切换工作区报错请先看运行 ridge / cargo tauri dev 的终端日志（搜索 [ridge][pty]）。Claude split 需在 Ridge 内建终端中运行，并确保 tmux shim 在 PATH 上。若出现 0xc0000142 这类进程级崩溃，需同时查看 Windows 事件查看器（应用程序日志）。',
    });
  }

  // 根据点击元素判断右键菜单目标类型
  function getContextMenuTarget(e: MouseEvent): {
    target: ContextMenuTarget;
    paneId?: string;
  } {
    const target = e.target as HTMLElement;

    // 检查是否点击在侧边栏区域
    if (target.closest('.rg-sidebar')) {
      return { target: 'sidebar' };
    }

    // 检查是否点击在工作区标签区域
    if (target.closest('.rg-workspace-tabs')) {
      return { target: 'workspace-tabs' };
    }

    // 检查是否点击在 Git 图谱区域
    if (target.closest('.rg-git-graph')) {
      return { target: 'git-graph' };
    }

    // 检查是否点击在分割条上
    if (target.closest('.splitpanes__splitter')) {
      return { target: 'splitter' };
    }

    // 检查是否点击在窗格标题栏
    if (target.closest('.rg-pane-header')) {
      return { target: 'pane-header' };
    }

    // 检查是否点击在终端或编辑器内容区域
    const paneEl =
      target.closest('.rg-pane-root') || target.closest('[data-pane-id]');
    if (paneEl) {
      const paneId =
        paneEl.getAttribute('data-pane-id') ||
        (paneEl as HTMLElement).dataset?.paneId;
      // 判断是终端还是编辑器（通过 class 判断）。
      // 历史 typo 修：`.rg-terminal` 实际类名是 `.rg-terminal-surface`
      // （Pane.svelte），`.rg-editor` 不存在（用 `.monaco-editor` 兜底）。
      // 不修这两条 contextmenu target 就只能落到 `pane-content`，菜单
      // 项也对应不上终端/编辑器特化项。
      const isTerminal =
        target.closest('.xterm') || target.closest('.rg-terminal-surface');
      const isEditor = target.closest('.monaco-editor');
      if (isTerminal) {
        return { target: 'terminal', paneId };
      }
      if (isEditor) {
        return { target: 'editor', paneId };
      }
      return { target: 'pane-content', paneId };
    }

    return { target: 'unknown' };
  }

  // 获取指定 pane 的模式（终端或编辑器）
  function getPaneMode(
    paneId: string | undefined
  ): 'terminal' | 'editor' | null {
    if (!paneId) return null;
    const findPaneMode = (node: PaneNode): 'terminal' | 'editor' | null => {
      if (node.type === 'leaf' && node.id === paneId) {
        return (node as any).mode || 'terminal';
      }
      if (node.type === 'split') {
        for (const child of node.children) {
          const result = findPaneMode(child);
          if (result) return result;
        }
      }
      return null;
    };
    return findPaneMode(rootNode);
  }

  /**
   * Real handler shared across menu items + the Ctrl+W shortcut.
   * Centralises the "close *this* pane" semantic so the menu fires the
   * same code path as the keyboard shortcut.
   */
  async function closeCurrentPane(targetPaneId?: string): Promise<void> {
    const pid = targetPaneId || get(activePaneId);
    if (!pid) return;
    try {
      await closePane(pid);
    } catch (e) {
      await alertDialog({ title: '关闭失败', message: String(e), danger: true });
    }
  }

  /** Close every leaf pane in the active workspace EXCEPT the given one. */
  async function closeOtherPanes(keepPaneId?: string): Promise<void> {
    const keep = keepPaneId || get(activePaneId);
    if (!keep) return;
    const ids = getAllPaneIds(rootNode).filter((id) => id !== keep);
    if (ids.length === 0) return;
    const ok = await confirmDialog({
      title: '关闭其它窗格',
      message: `将关闭 ${ids.length} 个窗格，仅保留当前窗格。继续？`,
      okLabel: '关闭',
      danger: true,
    });
    if (!ok) return;
    for (const id of ids) {
      try {
        await closePane(id);
      } catch {
        /* best-effort — keep going */
      }
    }
  }

  async function renameActiveWorkspace(): Promise<void> {
    const wid = get(activeWorkspaceId);
    if (!wid) return;
    const ws = get(workspacesList).find((w) => w.id === wid);
    const newName = await promptDialog({
      title: '重命名工作区',
      message: '输入新的工作区名称：',
      defaultValue: ws?.name ?? '',
      placeholder: '工作区名称',
    });
    if (!newName?.trim()) return;
    try {
      await renameWorkspace(wid, newName.trim());
    } catch (e) {
      await alertDialog({ title: '重命名失败', message: String(e), danger: true });
    }
  }

  /** Run a git command against the SCM-selected repo (or any one repo
   *  if SCM hasn't been opened yet). Surface errors in a themed alert. */
  async function runGitOnSelectedRepo(cmd: string, label: string): Promise<void> {
    if (!isTauri()) return;
    // Prefer the repo the SCM panel currently has selected (persisted in
    // scmCacheStore so it survives tab switches). Fall back to discovery
    // from paneCwdStore when SCM hasn't been opened yet.
    let repoRoot: string | null = getScmSelectedRepo() || null;
    if (!repoRoot) {
      const cwds = Array.from(new Set(Object.values(get(paneCwdStore))));
      for (const cwd of cwds) {
        try {
          const r = await invoke<string | null>('find_git_repo_root', { path: cwd });
          if (r) {
            repoRoot = r;
            break;
          }
        } catch {
          /* try next */
        }
      }
    }
    if (!repoRoot) {
      await alertDialog({
        title: `${label} 失败`,
        message: '当前工作区中没有任何 pane 处于 git 仓库内。',
        danger: true,
      });
      return;
    }
    try {
      await invoke(cmd, { repoRoot });
      // Tell the SCM panel + pane pills to refresh.
      window.dispatchEvent(
        new CustomEvent('ridge:scm-focus-repo', { detail: repoRoot })
      );
    } catch (e) {
      await alertDialog({ title: `${label} 失败`, message: String(e), danger: true });
    }
  }

  function copyPaneCwd(targetPaneId?: string): void {
    const pid = targetPaneId || get(activePaneId);
    if (!pid) return;
    const wid = get(activeWorkspaceId);
    const cwd = get(paneCwdStore)[`${wid}:${pid}`] ?? '';
    if (!cwd) {
      void alertDialog({ title: '复制路径', message: '该 pane 还未上报 cwd。' });
      return;
    }
    navigator.clipboard?.writeText(cwd).catch(() => {
      /* swallow — alert would fire too late after store unmount */
    });
  }

  function revealPaneCwd(targetPaneId?: string): void {
    if (!isTauri()) return;
    const pid = targetPaneId || get(activePaneId);
    if (!pid) return;
    const wid = get(activeWorkspaceId);
    const cwd = get(paneCwdStore)[`${wid}:${pid}`] ?? '';
    if (!cwd) return;
    void invoke('reveal_in_file_manager', { path: cwd });
  }

  // 生成右键菜单项
  function getContextMenuItems(
    target: ContextMenuTarget,
    paneId?: string
  ): ContextMenuItem[] {
    const items: ContextMenuItem[] = [];

    switch (target) {
      case 'terminal':
      case 'editor':
      case 'pane-content':
        items.push(
          {
            id: 'split-h',
            label: '水平分割',
            icon: Columns,
            shortcut: 'Ctrl+Shift+H',
            action: () => splitActivePane('horizontal'),
          },
          {
            id: 'split-v',
            label: '垂直分割',
            icon: Rows,
            shortcut: 'Ctrl+Shift+V',
            action: () => splitActivePane('vertical'),
          },
          { divider: true, id: 'divider-1' },
          {
            id: 'close',
            label: '关闭当前窗格',
            icon: X,
            shortcut: 'Ctrl+W',
            action: () => void closeCurrentPane(paneId),
          },
          {
            id: 'close-others',
            label: '关闭其他窗格',
            icon: Trash2,
            action: () => void closeOtherPanes(paneId),
          },
          { divider: true, id: 'divider-2' },
          {
            id: 'focus',
            label: '聚焦当前窗格',
            icon: Maximize2,
            action: () => activePaneId.set(paneId || ''),
          },
          { divider: true, id: 'divider-3' },
          {
            id: 'copy-cwd',
            label: '复制 cwd 路径',
            icon: Copy,
            action: () => copyPaneCwd(paneId),
          },
          {
            id: 'reveal',
            label: '在文件管理器中显示 cwd',
            icon: FolderOpen,
            action: () => revealPaneCwd(paneId),
          }
        );
        break;

      case 'splitter':
        items.push(
          {
            id: 'split-h',
            label: '水平分割',
            icon: Columns,
            action: () => splitActivePane('horizontal'),
          },
          {
            id: 'split-v',
            label: '垂直分割',
            icon: Rows,
            action: () => splitActivePane('vertical'),
          }
          // NB: "均分窗格" 待后端 split_pane reset-ratios 命令支持后再启用。
        );
        break;

      case 'sidebar':
        items.push(
          {
            id: 'files',
            label: '文件浏览器',
            icon: FolderOpen,
            action: () => {
              sidebarTab = 'files';
              sidebarCollapsed = false;
              saveSidebarSettings();
            },
          },
          {
            id: 'search',
            label: '搜索',
            icon: Search,
            action: () => {
              sidebarTab = 'search';
              sidebarCollapsed = false;
              saveSidebarSettings();
            },
          },
          {
            id: 'git',
            label: '源代码管理',
            icon: GitBranch,
            action: () => {
              sidebarTab = 'git';
              sidebarCollapsed = false;
              saveSidebarSettings();
            },
          }
        );
        break;

      case 'workspace-tabs':
        items.push(
          {
            id: 'new-ws',
            label: '新建工作区',
            icon: Plus,
            action: () => createWorkspace(),
          },
          {
            id: 'rename',
            label: '重命名工作区',
            icon: MoreHorizontal,
            action: () => void renameActiveWorkspace(),
          },
          { divider: true, id: 'divider-1' },
          // 保存工作区入口在 Explorer 头部已有，菜单里不重复（避免双入口）。
          {
            id: 'close-ws',
            label: '关闭当前工作区',
            icon: X,
            // activeWorkspaceId is a store; read the current id at invocation time.
            action: () => closeWorkspace(get(activeWorkspaceId)),
          }
        );
        break;

      case 'git-graph':
        items.push(
          {
            id: 'open-scm',
            label: '打开源代码管理',
            icon: GitBranch,
            action: () => {
              sidebarTab = 'git';
              sidebarCollapsed = false;
              saveSidebarSettings();
            },
          },
          { divider: true, id: 'divider-1' },
          {
            id: 'fetch',
            label: 'Fetch',
            icon: Download,
            action: () => void runGitOnSelectedRepo('git_fetch', 'Fetch'),
          },
          {
            id: 'pull',
            label: 'Pull',
            icon: ArrowDown,
            action: () => void runGitOnSelectedRepo('git_pull', 'Pull'),
          },
          {
            id: 'push',
            label: 'Push',
            icon: ArrowUp,
            action: () => void runGitOnSelectedRepo('git_push', 'Push'),
          },
          {
            id: 'sync',
            label: 'Sync',
            icon: RefreshCw,
            action: () => void runGitOnSelectedRepo('git_sync', 'Sync'),
          }
        );
        break;

      case 'pane-header':
        items.push(
          {
            id: 'split-h',
            label: '水平分割',
            icon: Columns,
            action: () => splitActivePane('horizontal'),
          },
          {
            id: 'split-v',
            label: '垂直分割',
            icon: Rows,
            action: () => splitActivePane('vertical'),
          },
          { divider: true, id: 'divider-1' },
          {
            id: 'copy-cwd',
            label: '复制 cwd 路径',
            icon: Copy,
            action: () => copyPaneCwd(paneId),
          },
          {
            id: 'reveal',
            label: '在文件管理器中显示',
            icon: FolderOpen,
            action: () => revealPaneCwd(paneId),
          },
          { divider: true, id: 'divider-2' },
          {
            id: 'close',
            label: '关闭窗格',
            icon: X,
            action: () => void closeCurrentPane(paneId),
          }
        );
        break;

      default:
        items.push(
          {
            id: 'new-ws',
            label: '新建工作区',
            icon: Plus,
            action: () => createWorkspace(),
          }
        );
    }

    return items;
  }

  // 处理右键菜单事件
  function handleContextMenu(e: MouseEvent) {
    // T9：项目全局禁用系统默认右键菜单 —— 无论 target 是哪个，都先 preventDefault。
    // Monaco 自己的 contextmenu listener 早于本 document-level handler 跑，并已经
    // 弹出它自己的菜单（Go to Definition / Rename Symbol 等），prevent 不影响它。
    // 终端 / 编辑器 / 任何空白区域系统菜单都不会再出现。
    e.preventDefault();

    // resize 过程中不显示自定义菜单
    if (isResizeInProgress()) return;

    const { target, paneId } = getContextMenuTarget(e);

    // Monaco 已经显示了它自己的菜单 —— Ridge 不再叠加一层稀疏菜单。
    if (target === 'editor') return;

    const items = getContextMenuItems(target, paneId);
    showContextMenu(e.clientX, e.clientY, items, target, paneId);
  }

  // 侧栏切换 public event：任何组件（例如 pane 标题栏的 git pill）通过
  // `window.dispatchEvent(new CustomEvent('ridge:open-sidebar-tab', {detail:'git'}))`
  // 请求切 tab。把事件集中在 +page 这一层能避开跨组件 store 循环。
  function handleOpenSidebarTab(e: Event) {
    const detail = (e as CustomEvent<string>).detail;
    if (
      detail === 'files' ||
      detail === 'search' ||
      detail === 'git' ||
      (detail === 'claude' && $settingsStore.claudeExtensionEnabled)
    ) {
      sidebarTab = detail;
      if (sidebarCollapsed) {
        sidebarCollapsed = false;
        saveSidebarSettings();
      }
    }
  }

  onMount(() => {
    // 全局屏蔽默认右键菜单，显示自定义菜单
    document.addEventListener('contextmenu', handleContextMenu);
    window.addEventListener('ridge:open-sidebar-tab', handleOpenSidebarTab as EventListener);

    // 启动时把当前主题写到 <html data-rg-theme>，避免首帧短暂闪默认色。
    initSettingsBoot();

    // 文件系统监听桥接：订阅 explorer cwd + 编辑器外部文件，并把 fs-changed
    // 事件分发到文件树和编辑器。模块内部 idempotent，重复调用是安全的。
    initFileWatcherSync();

    // Track viewport width so `sidebarMaxPx` (80% cap) recomputes when
    // the user resizes the window — otherwise a 2000px-wide sidebar
    // could outlive a window shrunk to 1000px.
    const onResize = () => {
      viewportInnerWidth = window.innerWidth;
      // Defensive: clamp current sidebar width if it now exceeds the
      // shrunken cap. Persist so reload doesn't restore the over-cap value.
      if (sidebarWidth > sidebarMaxPx) {
        sidebarWidth = Math.max(0, sidebarMaxPx);
        saveSidebarSettings();
      }
    };
    window.addEventListener('resize', onResize);

    loadSidebarSettings();
    if (!isTauri()) return;
    let unlisten: (() => void) | undefined;
    let unlistenResized: (() => void) | undefined;
    void (async () => {
      await refreshWorkspaces();
      // 启动策略：从命令行 / 资源管理器启动时，以进程 cwd 为决策依据。
      // - cwd 顶层有 .ridge 文件：打开该工作区，并关掉默认空工作区（用户没交互过）；
      // - cwd 无 .ridge：默认工作区的根 pane 已在后端 `AppState::new` 中把 cwd 种为启动 cwd，
      //   这里不需要再做任何事，默认终端会自然落在启动目录。
      try {
        const ctx = await getStartupContext();
        if (ctx && ctx.wind_file_in_cwd) {
          const priorDefaultId = get(activeWorkspaceId);
          await openWorkspaceFromFile(ctx.wind_file_in_cwd);
          const nowActive = get(activeWorkspaceId);
          if (priorDefaultId && priorDefaultId !== nowActive) {
            try {
              await closeWorkspace(priorDefaultId);
            } catch (e) {
              console.warn('close default workspace after auto-open failed', e);
            }
          }
        }
      } catch (err) {
        console.warn('startup workspace resolution failed', err);
      }
      await refreshWorkspaceSaveInfo();
      // 检查初始最大化状态
      const win = getCurrentWindow();
      isMaximized = await win.isMaximized();
      unlistenResized = await win.onResized(async () => {
        isMaximized = await getCurrentWindow().isMaximized();
      });

      unlisten = await listen('teammate-layout-changed', () => {
        void (async () => {
          await syncPaneLayoutFromBackend();
          if (!dev) return;
          requestAnimationFrame(() => {
            const storeCount = getAllPaneIds(get(paneTreeStore)).length;
            const domCount = document.querySelectorAll('.rg-pane-root').length;
            if (storeCount > 0 && domCount !== storeCount) {
              reportDevIssue({
                title: 'Layout sync mismatch',
                message: `teammate-layout-changed 后 store panes=${storeCount}, mounted panes=${domCount}`,
              });
            }
          });
        })();
      });

      const unlistenActive = await listen<string>(
        'teammate-active-pane-changed',
        (e) => {
          const id = typeof e.payload === 'string' ? e.payload : '';
          if (!id) return;
          void (async () => {
            await syncPaneLayoutFromBackend();
            activePaneId.set(id);
          })();
        }
      );

      const prevUnlisten = unlisten;
      unlisten = () => {
        prevUnlisten?.();
        unlistenActive();
      };
    })();
    return () => {
      unlisten?.();
      unlistenResized?.();
      document.removeEventListener('contextmenu', handleContextMenu);
      window.removeEventListener('ridge:open-sidebar-tab', handleOpenSidebarTab as EventListener);
      window.removeEventListener('resize', onResize);
    };
  });

  // sidebar 图标按钮：颜色跟随主题 accent。原来写死 violet，浅色 / 棕色 / 绿色
  // 主题下整个 rail 仍是紫色调，与配色不符。
  const actBtn =
    'relative flex h-10 w-10 items-center justify-center rounded-xl text-lg transition-all duration-200 ' +
    'text-[var(--rg-fg-muted)] hover:bg-[var(--rg-accent)]/8 hover:text-[var(--rg-fg)]';
  const actBtnOn =
    ' bg-[var(--rg-accent)]/12 text-[var(--rg-accent)] ring-1 ring-[var(--rg-accent)]/35 shadow-[0_0_20px_-4px_var(--rg-accent-glow)]';

  const toolBtn =
    'flex h-8 w-8 shrink-0 items-center justify-center rounded-lg border border-[var(--rg-border)] ' +
    'bg-[var(--rg-surface)]/90 backdrop-blur-md text-[var(--rg-fg-muted)] ' +
    'hover:border-[var(--rg-accent)]/35 hover:text-[var(--rg-accent)] hover:bg-[var(--rg-accent)]/8 transition-colors';

  // 窗口控制按钮样式（跟随系统：Windows在右侧，macOS在左侧）
  const winCtrlBtn =
    'flex h-8 w-8 items-center justify-center rounded-lg text-[var(--rg-fg-muted)] hover:bg-[var(--rg-accent)]/8 hover:text-[var(--rg-fg)] transition-colors';
</script>

<svelte:window onkeydown={handleGlobalKeydown} />
<!-- Root must NOT carry `data-tauri-drag-region` — it makes Tauri intercept
     mousedown across the entire window, eating the gesture HTML5 DnD relies
     on to start a drag (round-38 bug: WorkspaceTabs reorder, pane drag,
     FileTree DnD, FileEditor tab reorder all silently broke). The OS-window
     drag region is correctly scoped to the top `<header>` (line ~1102) only,
     where there are no draggable children. -->
<div
  class="flex h-screen w-screen overflow-hidden bg-[var(--rg-bg)] text-[var(--rg-fg)] selection:bg-violet-500/25"
>
  <!-- 左侧图标导航栏 -->
  <aside
    class="w-[52px] shrink-0 flex flex-col items-center py-3 gap-1.5 border-r border-[var(--rg-border)] bg-[var(--rg-surface)]/35 backdrop-blur-2xl"
  >
    <button
      type="button"
      class="{actBtn}{sidebarTab === 'files' ? actBtnOn : ''}"
      title="文件"
      onclick={() => { sidebarTab = 'files'; expandSidebar(); }}
    >
      <FolderOpen class="h-5 w-5" />
    </button>
    <button
      type="button"
      class="{actBtn}{sidebarTab === 'search' ? actBtnOn : ''}"
      title="搜索 (Ctrl+Shift+F)"
      onclick={() => { sidebarTab = 'search'; expandSidebar(); }}
    >
      <Search class="h-5 w-5" />
    </button>
    <button
      type="button"
      class="{actBtn}{sidebarTab === 'git' ? actBtnOn : ''}"
      title="Git Graph"
      onclick={() => { sidebarTab = 'git'; expandSidebar(); }}
    >
      <GitBranch class="h-5 w-5" />
    </button>
    {#if $settingsStore.claudeExtensionEnabled}
      <!-- Claude Code 扩展开关：在 settings.claudeExtensionEnabled = true 时
           出现；点击切到 Claude 独立 tab。pane 标题栏的 Bot 按钮和原本嵌在
           Explorer 里的 claudeHistory 插件都跟随这一开关，统一在扩展面板里
           关闭即可全局禁用。 -->
      <button
        type="button"
        class="{actBtn}{sidebarTab === 'claude' ? actBtnOn : ''}"
        title="Claude Code"
        onclick={() => { sidebarTab = 'claude'; expandSidebar(); }}
      >
        <Bot class="h-5 w-5" />
      </button>
    {/if}

    <!-- Bottom-anchored extension manager — uses mt-auto so it stays at the
         rail's bottom regardless of how many tabs sit above. Click toggles
         the Claude Code extension. The icon flips between dim/Bot when off
         and accent/Bot when on, giving a single button that both tells the
         user the current state and lets them flip it without spelunking
         through nested settings. -->
    <button
      type="button"
      class="{actBtn} mt-auto"
      title="设置（外观、字体、搜索、扩展）"
      onclick={() => (settingsPanelOpen = true)}
    >
      <Settings class="h-4 w-4" />
    </button>
  </aside>
  <SettingsPanel open={settingsPanelOpen} onClose={() => (settingsPanelOpen = false)} />

  <!-- 侧边栏区域：wrapper 始终渲染，toggle 按钮始终可见 -->
  <div
    class="relative shrink-0 z-10"
    style="width: {sidebarCollapsed ? 0 : sidebarWidth}px; overflow: visible"
  >
    {#if !sidebarCollapsed}
      <aside
        class="h-full border-r border-[var(--rg-border)] bg-[var(--rg-surface-2)]/55 backdrop-blur-xl flex flex-col min-h-0 rg-scroll overflow-y-auto"
      >
        {#if sidebarTab === 'git'}
          <div
            data-tauri-drag-region
            class="px-3 h-11 items-center flex shrink-0 border-b border-[var(--rg-border)] text-xs font-semibold uppercase tracking-wider text-[var(--rg-fg-muted)]"
          >
            源代码管理
          </div>
          <div class="flex-1 min-h-0 overflow-hidden">
            <SourceControl />
          </div>
        {:else if sidebarTab === 'search'}
          <div class="flex-1 min-h-0 overflow-hidden">
            <SearchSidebar active={sidebarTab === 'search'} />
          </div>
        {:else if sidebarTab === 'claude' && $settingsStore.claudeExtensionEnabled}
          <ClaudeCodePanel />
        {:else}
          <div
            data-tauri-drag-region
            class="px-3 h-11 items-center flex justify-between shrink-0 border-b border-[var(--rg-border)] text-xs font-semibold uppercase tracking-wider text-[var(--rg-fg-muted)] relative"
          >
            <span>资源管理器</span>
            <!-- 打开 .ridge 已保存工作区入口（主按钮走 OS 文件选择器；chevron 展开最近列表）-->
            <div class="flex items-center gap-0.5">
              <button
                type="button"
                class="flex items-center gap-1 h-7 pl-2 pr-1 rounded-l text-[10px] font-medium normal-case tracking-normal text-[var(--rg-fg-muted)] hover:text-[var(--rg-fg)] hover:bg-[var(--rg-surface)] transition-colors"
                title="从 .ridge 文件打开已保存的工作区"
                onclick={() => void pickAndOpenWorkspace()}
              >
                <FolderInput class="h-3.5 w-3.5" /> 打开
              </button>
              <button
                bind:this={recentBtn}
                type="button"
                class="flex items-center justify-center h-7 w-5 rounded-r text-[10px] text-[var(--rg-fg-muted)] hover:text-[var(--rg-fg)] hover:bg-[var(--rg-surface)] transition-colors"
                title="最近打开的工作区"
                onclick={() => void loadRecentAndToggle()}
              >
                <ChevronDown class="h-3 w-3" />
              </button>
            </div>

            {#if recentOpen}
              <div
                style={recentPopupStyle}
                class="rg-popup w-[300px] max-w-[90vw]"
                role="menu"
                use:portal={{ id: 'recent-workspaces' }}
              >
                <div class="flex items-center justify-between h-7 px-3 bg-[var(--rg-surface)]/60 border-b border-[var(--rg-border)]/60 text-[10px] font-semibold uppercase tracking-wider text-[var(--rg-fg-muted)]">
                  <span>最近的工作区</span>
                  {#if recentList.length > 0}
                    <button
                      type="button"
                      class="text-[10px] normal-case tracking-normal hover:text-[var(--rg-fg)]"
                      onclick={handleClearRecent}
                    >
                      清空
                    </button>
                  {/if}
                </div>
                <div class="max-h-[260px] overflow-y-auto">
                  {#if recentList.length === 0}
                    <div class="px-3 py-2 text-[11px] text-[var(--rg-fg-muted)]">无历史记录</div>
                  {:else}
                    {#each recentList as p (p)}
                      <button
                        type="button"
                        class="group flex flex-col items-start w-full px-3 py-1.5 text-left hover:bg-[var(--rg-surface)] transition-colors normal-case tracking-normal"
                        onclick={() => void openRecent(p)}
                        title={p}
                      >
                        <span class="text-[12px] text-[var(--rg-fg)] truncate max-w-full">{basenameOf(p)}</span>
                        <span class="text-[10px] text-[var(--rg-fg-muted)] truncate max-w-full font-mono">{dirnameOf(p)}</span>
                      </button>
                    {/each}
                  {/if}
                </div>
              </div>
            {/if}
          </div>
          <div class="flex-1 min-h-0 overflow-hidden">
            {#if $activeWorkspaceId}
              <Explorer workspaceId={$activeWorkspaceId} />
            {:else}
              <div
                class="p-4 text-[13px] leading-relaxed text-[var(--rg-fg-muted)]"
              >
                请先选择一个工作区
              </div>
            {/if}
          </div>
        {/if}

        <!-- Global-scope plugin region — mounted once at the sidebar footer,
             visible across every tab. Keep it compact; plugins are expected
             to collapse their own heavy UI. -->
        <div class="shrink-0 border-t border-[var(--rg-border)]/40">
          <SidebarPluginRegion scope="global" />
        </div>

      </aside>
    {/if}
<!-- 侧边栏拖动条：始终渲染 — collapsed 时在 left-0（wrapper 宽度为0，左边界即导航栏右边缘）
     显示虚线；expanded 时在 right-0（侧边栏右边缘）作为透明可拖区域。
     wrapper 有 z-10 + overflow:visible，保证此元素即使在 collapsed 状态下也能响应点击。 -->
<!-- svelte-ignore a11y_no_noninteractive_tabindex -->
<!-- svelte-ignore a11y_no_noninteractive_element_interactions -->
<!-- T16：与 SplitContainer 终端 splitter 视觉对齐 —— 8px 命中区透明，
     ::before 画 1px var(--rg-border) 中线；hover/drag 时 scaleX(4) 变粗
     并切到 var(--rg-accent) + accent-glow 阴影。 -->
<div
  class="rg-sidebar-resize absolute top-0 h-full w-2 shrink-0 cursor-col-resize select-none z-30 {sidebarCollapsed ? 'left-0' : 'right-0'} {isResizingSidebar ? 'rg-sidebar-resize-active' : ''}"
  role="separator"
  aria-orientation="vertical"
  aria-label={sidebarCollapsed ? '拖动展开侧边栏' : '拖动调整侧边栏宽度'}
  tabindex="0"
  onmousedown={(e) => {
    if (sidebarCollapsed) {
      expandSidebar();
    } else {
      onSidebarResizerMouseDown(e);
    }
  }}
  onkeydown={(e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      if (sidebarCollapsed) {
        expandSidebar();
      } else {
        toggleSidebar();
      }
      e.preventDefault();
      return;
    }
    if (sidebarCollapsed) return;
    if (e.key !== 'ArrowLeft' && e.key !== 'ArrowRight') return;
    const step = e.shiftKey ? 64 : 16;
    const delta = e.key === 'ArrowRight' ? step : -step;
    const maxWidth = sidebarMaxPx;
    sidebarWidth = Math.max(0, Math.min(maxWidth, sidebarWidth + delta));
    if (sidebarWidth < 20) {
      sidebarCollapsed = true;
      sidebarWidth = 0;
    }
    saveSidebarSettings();
    e.preventDefault();
  }}
></div>

    <!-- T16：移除显式折叠按钮 —— 用户仍可通过 Ctrl+B 快捷键 / 拖到极窄宽度
         自动折叠（onMouseMove < 20 自动 collapse）实现折叠。 -->
  </div>

  <!-- 主内容区 -->
  <div class="flex-1 flex flex-col min-w-0 min-h-0">
    <!-- 顶部标题栏 -->
    <header
      class="h-11 flex items-center gap-2 px-2 border-b border-[var(--rg-border)] bg-[var(--rg-glass)] backdrop-blur-md min-w-0"
      data-tauri-drag-region
    >
      <!-- 左侧元素组 -->
      <div class="flex items-center gap-2 flex-1" data-tauri-drag-region>
        <!-- 工作区标签区 -->
        <WorkspaceTabs
          workspaces={$workspacesList}
          activeWorkspaceId={$activeWorkspaceId}
          onSwitch={switchWorkspace}
          onClose={closeWorkspace}
          onReorder={reorderWorkspaces}
          onRename={renameWorkspace}
        >
          <!-- 新建工作区按钮 -->
          {#snippet actions()}
            <button
              type="button"
              class="shrink-0 flex h-8 w-8 items-center justify-center rounded-lg border border-dashed border-[var(--rg-border)] text-[var(--rg-fg-muted)] hover:border-violet-400/40 hover:text-violet-200 hover:bg-violet-500/[0.06] transition-colors"
              title="新建根工作区（独立分屏树与终端）"
              onclick={() => createWorkspace()}
            >
              <span class="text-lg leading-none">+</span>
            </button>
          {/snippet}
        </WorkspaceTabs>

        <!-- 开发排障入口 -->
        {#if dev}
          <button
            type="button"
            class="rg-no-drag shrink-0 rounded-lg px-2.5 py-1.5 text-[11px] font-medium border border-red-500/30 text-red-300/90 hover:bg-red-500/10 transition-colors"
            title="开发排障入口"
            onclick={openDevIssueHelp}
          >
            Dev Issue
          </button>
        {/if}

        <!-- 编辑器抽屉开关：放在分屏按钮左侧，给"打开文件编辑器"一个常驻入口；
             toggle 行为——已显示时点一下隐藏，已隐藏时再点一下显示，与
             FileEditor 头部的左侧收起按钮形成开/关对偶。$fileEditorStore
             的 `isVisible` 用于切换图标突出态，让用户一眼就能看出当前面板
             状态。 -->
        <button
          type="button"
          class="rg-no-drag {toolBtn} {$fileEditorStore.isVisible ? 'bg-[var(--rg-accent)]/15 text-[var(--rg-accent)]' : ''}"
          title={$fileEditorStore.isVisible ? '收起文件编辑器' : '展开文件编辑器'}
          onclick={() => fileEditorStore.toggleVisibility()}
        >
          <PanelRightOpen class="h-4 w-4" />
        </button>

        <!-- 分屏操作按钮 -->
        <div
          class="rg-no-drag flex items-center gap-1 rounded-xl backdrop-blur-md"
        >
          <button
            type="button"
            class={toolBtn}
            title="左右分屏（当前选中窗格）"
            data-testid="add-pane-btn"
            onclick={() => void splitActivePane('horizontal')}
          >
            <svg
              class="h-4 w-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              aria-hidden="true"
            >
              <rect x="3" y="5" width="7" height="14" rx="1.5" />
              <rect x="14" y="5" width="7" height="14" rx="1.5" />
            </svg>
          </button>
          <button
            type="button"
            class={toolBtn}
            title="上下分屏（当前选中窗格）"
            onclick={() => void splitActivePane('vertical')}
          >
            <svg
              class="h-4 w-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
              aria-hidden="true"
            >
              <rect x="4" y="4" width="16" height="7" rx="1.5" />
              <rect x="4" y="13" width="16" height="7" rx="1.5" />
            </svg>
          </button>
        </div>

        <!-- 窗口控制按钮（右侧）：wf-no-drag 避免与标题栏拖动区域冲突 -->
      </div>
      <div class="rg-no-drag flex items-center gap-1 shrink-0">
        <button
          type="button"
          class={winCtrlBtn}
          title="最小化"
          onclick={handleMinimize}
        >
          <svg
            class="h-4 w-4"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path d="M5 12h14" stroke-linecap="round" />
          </svg>
        </button>
        <button
          type="button"
          class={winCtrlBtn}
          title={isMaximized ? '还原' : '最大化'}
          onclick={handleMaximize}
        >
          {#if isMaximized}
            <svg
              class="h-4 w-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <rect x="5" y="9" width="10" height="10" rx="1" />
              <path d="M9 9V5h10v10h-4" />
            </svg>
          {:else}
            <svg
              class="h-4 w-4"
              viewBox="0 0 24 24"
              fill="none"
              stroke="currentColor"
              stroke-width="2"
            >
              <rect x="4" y="4" width="16" height="16" rx="2" />
            </svg>
          {/if}
        </button>
        <button
          type="button"
          class="{winCtrlBtn} hover:bg-red-500/20 hover:text-red-400"
          title="关闭"
          onclick={handleClose}
        >
          <svg
            class="h-4 w-4"
            viewBox="0 0 24 24"
            fill="none"
            stroke="currentColor"
            stroke-width="2"
          >
            <path d="M18 6L6 18M6 6l12 12" stroke-linecap="round" />
          </svg>
        </button>
      </div>
    </header>

    <!-- 工作区内容：flex-row 让嵌入模式的 FileEditor 作为右侧列，
         drawer/floating 模式的 FileEditor 通过 position:fixed 脱离普通流，不占用此空间。 -->
    <div
      class="relative flex-1 min-h-0 min-w-0 overflow-hidden flex flex-row bg-[var(--rg-bg-raised)]"
    >
      <div class="flex-1 min-w-0 min-h-0 overflow-hidden flex flex-col">
        {#if $activeWorkspaceId && hasPaneLayout}
          {#key $activeWorkspaceId}
            <SplitContainer workspaceId={$activeWorkspaceId} node={rootNode} />
          {/key}
        {:else}
          <div
            class="flex flex-1 items-center justify-center text-[13px] text-[var(--rg-fg-muted)]"
          >
            正在加载工作区…
          </div>
        {/if}
      </div>
      <!-- 文件编辑器：嵌入模式时为右侧 flex 列；抽屉/悬浮模式时 position:fixed 脱离流 -->
      <FileEditor />
    </div>
  </div>

</div>

<!-- ── 顶层浮层区 ─────────────────────────────────────────────────────────
     以下组件使用 position:fixed，必须作为根 <div> 的兄弟节点而非其子节点，
     确保它们不受根容器任何 CSS transform / backdrop-filter / overflow 限制，
     始终以整个应用窗口为参照系居中或定位。 -->

<!-- alert / confirm / prompt 替代浏览器原生 dialog -->
<WindDialog />
<!-- 轻量 toast 通知 (z-10000，位于所有 modal 之上) -->
<WindToast />
<!-- 全局右键菜单 -->
<ContextMenu />
<!-- Claude Code 启动 modal -->
<ClaudeAgentLauncher />
<!-- 终端滚动历史浏览器 -->
<ScrollbackHistoryModal />
